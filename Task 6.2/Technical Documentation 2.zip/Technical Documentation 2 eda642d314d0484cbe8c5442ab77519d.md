# Technical Documentation 2

---

# **Technical Documentation: Software Low Pass Filter Design for WALL-E's Rotary Encoder Interface**

## **Table of Contents**

1. **Introduction**
    - Purpose
    - Scope
2. **Requirements**
    - **Hardware and** Software Requirement
3. **Design Considerations**
    - Cutoff Frequency Calculation
    - LPF Implementation
4. **Arduino Implementation**
    - Software Implementation
5. **Usage and Integration**
    - Reading Filtered Encoder Data
    - Custom Control Algorithm
6. **Conclusion**

---

## **1. Introduction**

### **Purpose**

This technical documentation outlines the design and implementation of a Software Practical Low Pass Filter (LPF) for WALL-E's rotary encoder interface using an Arduino. The LPF is designed to improve the accuracy of position data obtained from the encoder while filtering out high-frequency noise.

### **Scope**

The scope of this documentation includes the calculation of the cutoff frequency (**`fc`**), LPF design considerations, and step-by-step implementation using an Arduino. The document also covers the integration of the LPF into WALL-E's control system.

## **2. Requirements**

### **Hardware and Software Requirements**

- Arduino board (e.g., Arduino Uno)
- Rotary encoder with A and B channels
- Connection wires
- Appropriate resistors and capacitors for LPF
- Arduino IDE (Integrated Development Environment)

## **3. Design Considerations**

### **Cutoff Frequency Calculation**

To determine the proper cutoff frequency (**`fc`**) for the LPF, the following parameters are considered:

- Encoder specifications: 540 pulses per revolution
- Wheel specifications: 40cm diameter
- Maximum speed of WALL-E: 0.5 m/s

The following formula is used to calculate **`fc`**:

$$
fc = 0.1 * ω_enc
$$

Where:

- **`ω_enc`** is the maximum angular frequency in radians per second for the encoder.

### **LPF Implementation**

A first-order LPF is implemented to filter out high-frequency noise from the encoder signal. The LPF is designed with a time constant (**`alpha`**) based on **`fc`** and a time interval (**`dt`**).

## **4. Arduino Implementation**

### **Hardware Setup**

1. Connect the A and B channels of the rotary encoder to the Arduino's digital input pins. Update **`encoderPinA`** and **`encoderPinB`** in the code to match the actual pins used.
2. Set up the necessary resistors and capacitors to create the low-pass filter according to the desired **`fc`** value. Ensure proper connections to filter the encoder output signal.

### **Software Implementation**

The Arduino code implements the LPF and provides access to the filtered encoder count. Key steps in the code include:

- Initialization of encoder pins and interrupt handling.
- Calculation of filtered encoder count (**`filteredCount`**) using the LPF formula.
- A sample **`loop()`** function that demonstrates reading the filtered count and allowing for custom control algorithms to be implemented.

## **5. Usage and Integration**

### **Reading Filtered Encoder Data**

The filtered encoder count (**`filteredCount`**) can be accessed in the Arduino sketch and used for various purposes, such as navigation or feedback control.

### **Custom Control Algorithm**

Custom control algorithms can be implemented in the **`loop()`** function to utilize the filtered encoder data for WALL-E's navigation and control tasks.

## **6. Conclusion**

This technical documentation has provided a comprehensive guide on designing and implementing a Software Practical Low Pass Filter (LPF) for WALL-E's rotary encoder interface using an Arduino. By correctly determining the cutoff frequency (**`fc`**) and applying the LPF, WALL-E can enhance its navigation capabilities while filtering out noise from the encoder signal, contributing to its mission of caring for the planet.